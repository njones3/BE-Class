// Copyright (c) 2021 Promineo Tech

package recipes;

/**
 * This class contains the "main" method - the entry point to a Java
 * application.
 * 
 * @author Promineo
 *
 */
public class Recipes {

  /**
   * @param args
   */
  public static void main(String[] args) {}

}
